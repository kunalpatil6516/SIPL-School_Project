package com.school.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.school.dto.StudentDto;
import com.school.entity.Student;
import com.school.mapper.StudentMapper;
import com.school.repository.SchoolRepository;
import com.school.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private SchoolRepository repo;

//	@Override
//	public List<Student> findAll() {
//		return repo.findAll();
//	}

	@Override
	public StudentDto findStudentById(Long id) {
		Student stud=repo.findById(id).orElse(null);
		return StudentMapper.mapToStudentDto(stud);
	}

	@Override
	public StudentDto newStudent(Student student) {
		Student stud=repo.save(student);
		return StudentMapper.mapToStudentDto(stud);
	}

	@Override
	public StudentDto updateStudent(Student student) {
		Student stud=repo.save(student);
		return StudentMapper.mapToStudentDto(stud);
	}

	@Override
	public void deleteStudentById(Long id) {
		repo.deleteById(id);
		
	}

}
