package com.school.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.school.dto.StudentDto;
import com.school.entity.Student;

@Service
public interface StudentService {
//	List<Student> findAll();
	
	StudentDto findStudentById(Long id);
	
	StudentDto newStudent(Student student);
	
	StudentDto updateStudent(Student student);
	
	void deleteStudentById(Long id);
	
}
