package com.school.mapper;

import com.school.dto.StudentDto;
import com.school.entity.Student;

public class StudentMapper {
	
	public static StudentDto mapToStudentDto(Student stud) {
		StudentDto student=new StudentDto(stud.getId(),stud.getName(),stud.getCourse());
		return student;
		
	}
	
	public static Student mapToStudent(StudentDto stud) {
		Student student=new Student(stud.getId(),stud.getName(),stud.getCourse());
		return student;
		
	}

}
