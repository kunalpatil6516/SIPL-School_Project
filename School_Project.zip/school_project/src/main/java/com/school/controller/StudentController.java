package com.school.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.school.dto.StudentDto;
import com.school.entity.Student;
import com.school.mapper.StudentMapper;
import com.school.serviceImpl.StudentServiceImpl;


@RestController
@RequestMapping("/api/school")
public class StudentController {
	
	@Autowired
	StudentServiceImpl service;
	
	
	
public StudentController(StudentServiceImpl service) {
		super();
		this.service = service;
	}

//	@GetMapping("/getall")
//	public List<Student> getallcont(){
//		return service.findAll();
//	}
	
	@GetMapping("/{id}")
	public StudentDto getViaId(@PathVariable("id") Long id) {
		return service.findStudentById(id);
	}
	
	@PostMapping()
	public StudentDto create(@RequestBody Student student) {
		return service.newStudent(student);
	}
	
	@PutMapping("/{id}")
	public StudentDto updating(@PathVariable("id") long id,@RequestBody Student student) {
		StudentDto stud=service.findStudentById(id);
		stud.setName(student.getName());
		stud.setCourse(student.getCourse());
		return service.updateStudent(StudentMapper.mapToStudent(stud));
	}
	
	@DeleteMapping("/{id}")
	public void deleting(@PathVariable("id") long id) {
		service.deleteStudentById(id);
	}

}
